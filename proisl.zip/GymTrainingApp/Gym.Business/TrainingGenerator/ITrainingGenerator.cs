﻿using Gym.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym.Business.TrainingGenerator
{
    public interface ITrainingGenerator
    {
        void GenerateTraining(int idAimOfTraining, int idTrainingTypeSequence, int idTraining);
    }
}
